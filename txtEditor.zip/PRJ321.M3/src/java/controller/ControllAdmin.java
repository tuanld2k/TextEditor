/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DBConnect;

/**
 *
 * @author nguoitamxa
 */
public class ControllAdmin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
              DBConnect dbConn = new DBConnect();
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
         String service = request.getParameter("service");
            //check service -- not exception
            if (service == null) {
                service = "listAll";
            }

            if (service.equalsIgnoreCase("listAll")) {
                // do task
                out.println("<table border=\"1\">\n"
                        + "            <thead>\n"
                        + "                <tr>\n"
                        + "                    <th>ID</th>\n"
                        + "                    <th>Name</th>\n"
                        + "                    <th>Image</th>\n"
                        + "                    <th>Quantity</th>\n"
                        + "                    <th>Price</th>\n"
                        + "                    <th>Description</th>\n"
                        + "                    <th>Status</th>\n"
                        + "                    <th>Delete</th>\n"
                        + "                    <th>update</th>\n"
                        + "                </tr>\n"
                        + "            </thead>\n"
                        + "            <tbody>");
                String sql = "select * from Product";
                ResultSet rs = dbConn.getData(sql);
                while (rs.next()) {
                    out.println("<tr>\n"
                            + "                    <td>" + rs.getString("pid") + "</td>\n"
                            + "                    <td>" + rs.getString("pname") + "</td>\n"
                            + "                    <td> <img src=\"" + rs.getString("image") + "\"/></td>\n"
                            + "                    <td>" + rs.getInt("quantity") + "</td>\n"
                            + "                    <td>" + rs.getDouble("price") + "</td>\n"
                            + "                    <td>" + rs.getString("description") + "</td>\n"
                            + "                    <td>" + (rs.getInt("status") == 1 ? "Enable" : "Disable") + "</td>\n"
                            + "                    <td> <p><a href=\"ControllerProduct?service=delete&pid=" + rs.getString("pid") + "\">delete</a></p></td>\n"
                            + "                    <td> <p><a href=\"ControllerProduct?service=preUpdate&pid=" + rs.getString("pid") + "\">update</a></p></td>\n"
                            + "                </tr>");
                }

                out.println(" </tbody>\n"
                        + "        </table>");
                
                 RequestDispatcher dis = request.getRequestDispatcher("/ContentAdmin.jsp");
                // run
                dis.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ControllAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ControllAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
