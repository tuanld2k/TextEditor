/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Acount;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DAOAcount;

/**
 *
 * @author nguoitamxa
 */
public class LoginController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String user = request.getParameter("user");
        String pass = request.getParameter("pass");

        DAOAcount db = new DAOAcount();
        String account = db.getAccountByUserAndPass(user, pass);

        if (account != null) {
            request.getSession().setAttribute("account", account);
            request.setAttribute("acc", account);
            if (db.getRoleByUandP(user)==0) {
                response.sendRedirect("ControlleritemList?service=listAll");
            } else if (db.getRoleByUandP(user)==1) {
                response.sendRedirect("indexAdmin.jsp");
            }
        } else {
            response.sendRedirect("login.jsp");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
