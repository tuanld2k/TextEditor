/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Acount;
import entity.Product;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DAOProduct;
import model.DBConnect;

/**
 *
 * @author nguoitamxa
 */
@WebServlet(name = "ControlleritemList", urlPatterns = {"/ControlleritemList"})
public class ControlleritemList extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html;charset=UTF-8");
        DBConnect dbconn = new DBConnect();
        DAOProduct dao = new DAOProduct();

        try (PrintWriter out = response.getWriter()) {
            // get serice
            String service = request.getParameter("service");
            //check service -- not exception
            if (service == null) {
                service = "listAll";
            }
            
             if (service.equalsIgnoreCase("listAll")) {
                ArrayList<Product> arr = dao.displayAllProduct();
                // other data   
                // set data for view                         
                request.setAttribute("list", arr);
                // call view 
                // RequestDispatcher dis=request.getRequestDispatcher(URL);
                // URL: jsp, servlet, syntag:  /name
                RequestDispatcher dis = request.getRequestDispatcher("/index.jsp");
                // run
                dis.forward(request, response);
            }
            
            if (service.equalsIgnoreCase("listcate")) {
                ArrayList<Product> arr = dao.displayAllProductBycateID(Integer.parseInt(request.getParameter("cateID")));
                // other data           
                request.setAttribute("list", arr);
                // call view 
                // RequestDispatcher dis=request.getRequestDispatcher(URL);
                // URL: jsp, servlet, syntag:  /name
                RequestDispatcher dis = request.getRequestDispatcher("/index.jsp");
                // run
                dis.forward(request, response);
            }
            if (service.equalsIgnoreCase("logout")) {
                RequestDispatcher dis = request.getRequestDispatcher("/logout.jsp");
                // run
                dis.forward(request, response);
            }
            if (service.equalsIgnoreCase("login")) {
                RequestDispatcher dis = request.getRequestDispatcher("/login.jsp");
                // run
                dis.forward(request, response);
            }

                

//            if (service.equalsIgnoreCase("listName")) {
//                out.println("<tr>\n"
//                        + "                    <td><b> Choose Product Name:</b></td>\n"
//                        + "                    <td>\n"
//                        + "                            <select name=\"CateSelect\">");
//
//                String Sql = "select * from Product";
//                ResultSet rs = dbConn.getData(Sql);
//
//                while (rs.next()) {
//                    out.println(" <option value=\"" + rs.getInt(1) + "\">" + rs.getString(2) + "</option></tr>");
//                }
//            }
            if (service.equalsIgnoreCase("remove")) {
                String id = request.getParameter("id");
                request.getSession().removeAttribute(id);
                response.sendRedirect("showCart.jsp");
            }
            if (service.equalsIgnoreCase("removeall")) {
                request.getSession().invalidate();
                response.sendRedirect("showCart.jsp");
            }

            if (service.equalsIgnoreCase("addProduct")) {
//                out.println("<form action=\"ControllerProduct\" method=\"post\">\n"
//                        + "            <table border=\"0\">");
//                out.println(" <tr>\n"
//                        + "<tr>\n"
//                        + "                    <td>Product ID</td>\n"
//                        + "                    <td><input type=\"text\" name=\"ProductID\" value=\"\" /></td>\n"
//                        + "                </tr>"
//                        + "                    <td>Name</td>\n"
//                        + "                    <td><input type=\"text\" name=\"Name\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Quantity</td>\n"
//                        + "                    <td><input type=\"text\" name=\"quantity\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Price</td>\n"
//                        + "                    <td><input type=\"text\" name=\"Price\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>image</td>\n"
//                        + "                    <td><input type=\"text\" name=\"image\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>description</td>\n"
//                        + "                    <td><input type=\"text\" name=\"description\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Status</td>\n"
//                        + "                    <td> <input type=\"radio\" name=\"st\" value=\"1\" checked />Enable\n"
//                        + "                        <input type=\"radio\" name=\"st\" value=\"0\" />disable</td>\n"
//                        + "                </tr>");
//                out.println("<tr>\n"
//                        + "                    <td><b> Choose Category Name:</b></td>\n"
//                        + "                    <td>\n"
//                        + "                            <select name=\"Cate\">");
//
//                String Sql = "select * from Category";
//                 ResultSet rs = dbconn.getData(Sql);
//
//                while (rs.next()) {
//                    out.println(" <option value=\"" + rs.getInt(1) + "\">" + rs.getString(2) + "</option>");
//                }
//
//                out.println("/select>\n"
//                        + "                        </td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td><input type=\"submit\"  value=\"Insert\" /></td>\n"
//                        + "                    <td><input type=\"reset\"></td>\n"
//                        + "                </tr>\n"
//                        + "            </table>\n"
//                        + "        </form>");
                RequestDispatcher dis = request.getRequestDispatcher("/addPro.jsp");
                dis.forward(request, response);

            }
              if (service.equals("addCustomer")) {
//                out.println("<form action=\"ControllerCustomer\" method=\"post\">\n"
//                        + "            <table border=\"0\">             \n"
//                        + "                <tr>\n"
//                        + "                    <td>Name</td>\n"
//                        + "                    <td><input type=\"text\" name=\"Name\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Phone</td>\n"
//                        + "                    <td><input type=\"text\" name=\"phone\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Address</td>\n"
//                        + "                    <td><input type=\"text\" name=\"address\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                \n"
//                        + "                <tr>\n"
//                        + "                    <td>Username</td>\n"
//                        + "                    <td><input type=\"text\" name=\"user\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Password</td>\n"
//                        + "                    <td><input type=\"text\" name=\"pass\" value=\"\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
                
//                        + "                    <td>Status</td>\n"
//                        + "                    <td> <input type=\"radio\" name=\"st\" value=\"1\" checked />Enable\n"
//                        + "                        <input type=\"radio\" name=\"st\" value=\"0\" />disable</td>\n"
//                        + "                </tr>\n"
//                        + "               \n"
//                        + "                <tr>\n"
//                        + "                    <td><input type=\"submit\"  value=\"Insert\" /></td>\n"
//                        + "                    <td><input type=\"reset\"></td>\n"
//                        + "                </tr>\n"
//                        + "            </table>\n"
//                        + "        </form>");
                RequestDispatcher dis = request.getRequestDispatcher("/ControllerCustomer?service=addCustomer");
                dis.forward(request, response);

            }

               if (service.equals("showCart")) {
                    String sql = "select * from Product";
                ResultSet rs = dbconn.getData(sql);
                ArrayList<Product> arr = dao.displayAllProduct();
                // other data
                String title = "List of item";
                // set data for view
            
              
                request.setAttribute("rs", rs);
                request.setAttribute("list", arr);
                request.setAttribute("tieude", title);
                RequestDispatcher dis = request.getRequestDispatcher("itemList.jsp");
                dis.forward(request, response);

            }
            if (service.equals("preUpdate")) {
//                Product pr = new DAOProduct().getProductbyID(request.getParameter("id"));
//                out.println("<form action=\"ControllerProduct\" method=\"get\">\n"
//                        + "            <table border=\"0\">");
//                out.println(" <tr>\n"
//                        + "                    <td>Product ID</td>\n"
//                        + "                    <td><input type=\"hidden\" name=\"ProductID\" value=\"" + pr.getPid() + "\" />" + request.getParameter("id") + "</td>\n"
//                        + "</tr>"
//                        + "<tr>"
//                        + "                    <td>Name</td>\n"
//                        + "                    <td><input type=\"text\" name=\"Name\" value=\"" + pr.getPname() + "\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Quantity</td>\n"
//                        + "                    <td><input type=\"text\" name=\"quantity\" value=\"" + pr.getQuantity() + "\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Price</td>\n"
//                        + "                    <td><input type=\"text\" name=\"Price\" value=\"" + pr.getPrice() + "\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>image</td>\n"
//                        + "                    <td><input type=\"text\" name=\"image\" value=\"" + pr.getImage() + "\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>description</td>\n"
//                        + "                    <td><input type=\"text\" name=\"description\" value=\"" + pr.getDescription() + "\" /></td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td>Status</td>\n"
//                );
//                if ((pr.getStatus() == 1)) {
//                    out.println(""
//                            + "                    <td> "
//                            + "                        <input type=\"radio\" name=\"st\" value=\"" + pr.getStatus() + "\" checked/>Enable\n"
//                            + "                        <input type=\"radio\" name=\"st\" value=\"" + pr.getStatus() + "\" />Disable");
//                } else {
//                    out.println(""
//                            + "                    <td> "
//                            + "                        <input type=\"radio\" name=\"st\" value=\"" + pr.getStatus() + "\"/>Enable\n"
//                            + "                        <input type=\"radio\" name=\"st\" value=\"" + pr.getStatus() + "\" checked/>Disable");
//                }
//
//                out.println("<tr>\n"
//                        + "                    <td><b> Choose Category Name:</b></td>\n"
//                        + "                    <td>\n"
//                        + "                            <select name=\"Cate\">");
//
//                String Sql = "select * from Category";
//                ResultSet rs = dbconn.getData(Sql);
//
//                while (rs.next()) {
//                    if (Integer.parseInt(rs.getString(1)) == pr.getCateID()) {
//                        out.println("<option value=\"" + rs.getString(1) + "\" selected>" + rs.getString(2) + "</option>");
//                    } else {
//                        out.println(" <option value=\"" + rs.getString(1) + "\">" + rs.getString(2) + "</option>");
//                    }
//                }
//
//                out.println("/select>\n"
//                        + "                        </td>\n"
//                        + "                </tr>\n"
//                        + "                <tr>\n"
//                        + "                    <td><input type=\"submit\"  value=\"Update\" /></td>\n"
//                        + "                    <td><input type=\"reset\"></td>\n"
//                        + "                </tr>\n"
//                        + "            </table>\n"
//                        + "        </form>");
//
//                int pid = Integer.parseInt(request.getParameter("ProductID"));
//                String name = request.getParameter("Name");
//                int quantity = Integer.parseInt(request.getParameter("quantity"));
//                double price = Double.parseDouble(request.getParameter("Price"));
//                String images = request.getParameter("image");
//                String des = request.getParameter("description");
//                int status = Integer.parseInt(request.getParameter("st"));
//                int cateid = Integer.parseInt(request.getParameter("Cate"));
//                Product k = new Product(pid, name, quantity, price, images, des, status, cateid);
//                DAOProduct db = new DAOProduct();
//                db.updateProduct(k);
                DAOProduct abc = new DAOProduct();
//                ArrayList<Product> ad = abc.getProductbyID(request.getParameter("id"));
                // other data
                String title = "Update of Product";
                // set data for view
//                request.setAttribute("acc", ad);
                request.setAttribute("tieude", title);
                // call view 
                // RequestDispatcher dis=request.getRequestDispatcher(URL);
                // URL: jsp, servlet, syntag:  /name
                RequestDispatcher dis = request.getRequestDispatcher("/updateProduct.jsp");
                // run
                dis.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
