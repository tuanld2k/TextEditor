/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entity.Acount;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
public class DAOAcount extends DBConnect {
    
    public Acount getAcountByID(String id) {
        Acount admin = null;
        String sql = "select * from admin "
                + " where adminID=" + id;
        try {
            Statement state = conn.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = state.executeQuery(sql);
//            ResultSet rs=dbConn.getData(sql);
            while (rs.next()) {
                int adminID = rs.getInt("adminID");
                String username = rs.getString("username");
                String password = rs.getString("password");
                admin = new Acount(adminID, username, password);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOAcount.class.getName()).log(Level.SEVERE, null, ex);
        }
        return admin;
    }

    public int updateAcount(Acount admin) {
        int n = 0;
        String sql = "update admin set username='" + admin.getUser() + "',password='" + admin.getPass() + "' where adminID='" + admin.getId() + "';";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            n = pre.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAOCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return n;
    }

    public int getRoleByUandP(String user) {
        int role = 0;
        String sql = "select role from Role r, Account a  where r.id = a.adminID and a.username = '"+user+"'";       
         try {
             Statement state = conn.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = state.executeQuery(sql);
                        while (rs.next()) {
                            role = rs.getInt("role");
                        }    
        } catch (SQLException ex) {
            Logger.getLogger(DAOAcount.class.getName()).log(Level.SEVERE, null, ex);
        }
        return role;      
    }
    
    public int deleteAd(int pid) {
        int n = 0;
        String sql = "delete  from Acount where adminID= '" + pid + "'";
        //step1: check Bill has pid? (select)
        // step 1yes: change status 1-0
        //n0: delete
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            n = pre.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAOProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
        return n;
    }

    public int changePassword(int id, String user,
            String oldPass, String newPass) {
        int n = 0;
        // check userName is true (user, oldPass)
        String sql = "update Acount set password=? where adminID=? ";

        return n;
    }

    public int addAcount(Acount admin) {
        int n = 0;
        String preSQL = "insert into Acount(username,password)"
                + " values(?,?)";
        try {
            // ? has index start 1
            PreparedStatement pre = conn.prepareStatement(preSQL);
//            pre.setDataType(index of ?, value);
//            dataType is data of ?
            pre.setString(1, admin.getUser());
            pre.setString(2, admin.getPass());

            // execute
            n = pre.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAOCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return n;
    }

    public ArrayList displayAcount() {
        ArrayList<Acount> adList = new ArrayList<>();
        String sql = "SELECT adminID\n"
                + "      ,username\n"
                + "      ,password\n"
                + "  FROM admin";
        try {
            Statement state = conn.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = state.executeQuery(sql);
//            ResultSet rs=dbConn.getData(sql);
            while (rs.next()) {
                int adminID = rs.getInt("adminID");
                String username = rs.getString("username");
                String password = rs.getString("password");

                Acount admin = new Acount(adminID, username, password);

                adList.add(admin);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return adList;
    }

//    public void SortAscAcount() {
//        String sql = "SELECT [adminID]\n"
//                + "      ,[username]\n"
//                + "      ,[password]\n"
//                + "  FROM [dbo].[admin] order by username asc;";
//        try {
//            Statement state = conn.createStatement(
//                    ResultSet.TYPE_SCROLL_SENSITIVE,
//                    ResultSet.CONCUR_UPDATABLE);
//            ResultSet rs = state.executeQuery(sql);
////            ResultSet rs=dbConn.getData(sql);
//            while (rs.next()) {
//                int adminID = rs.getInt("adminID");
//                String username = rs.getString("username");
//                String password = rs.getString("password");
//
//                Acount admin = new Acount(adminID, username, password);
//                System.out.println(admin);
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(DAOCustomer.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    public String getAccountByUserAndPass(String user, String pass) {

        try {
            String sql = "SELECT username FROM Account WHERE username = ?\n"
                    + "AND password = ?";
            PreparedStatement stm = conn.prepareStatement(sql);
            stm.setString(1, user);
            stm.setString(2, pass);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                String admin;
                admin=rs.getString("username");
//                admin.setAcountID(rs.getInt("adminID"));
//                admin.setPassword(rs.getString("password"));
                return admin;
            }
        } catch (SQLException e) {
            Logger.getLogger(DAOAcount.class.getName()).log(Level.SEVERE, null, e);
        }
        return null;
    }

    public static void main(String[] args) {
        DAOAcount db = new DAOAcount();
        System.out.println(db.getRoleByUandP("customer"));

    }

}
